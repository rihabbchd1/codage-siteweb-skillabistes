from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Skillabiste, Stage, Projet

@admin.register(Skillabiste)
class SkillabisteAdmin(admin.ModelAdmin):
    list_display = ('user', 'telephone', 'periode_stage', 'encadrant')

@admin.register(Stage)
class StageAdmin(admin.ModelAdmin):
    list_display = ('skillabiste', 'statut')
@admin.register(Projet)
class ProjetAdmin(admin.ModelAdmin):
    list_display = ('titre', 'partenaire_nom', 'domaine')

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'role', 'is_staff', 'is_superuser')
    fieldsets = UserAdmin.fieldsets + (
        ('Rôle personnalisé', {'fields': ('role',)}),
    )



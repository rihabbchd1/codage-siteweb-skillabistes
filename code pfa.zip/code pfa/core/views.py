from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import logout
def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if user.role == "admin":
                return redirect('/admin/')
            elif user.role == "skillabiste":
                return redirect('/skillabiste/dashboard/')
            elif user.role == "partenaire":
                return redirect('/partenaire/dashboard/')
        else:
            messages.error(request, "Nom d'utilisateur ou mot de passe incorrect.")

    return render(request, 'login.html')

def register_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        role = request.POST.get("role")

        User = get_user_model()
       
        if User.objects.filter(username=username).exists():
            messages.error(request, "Ce nom d'utilisateur existe déjà.")
            return redirect('register')

        user = User.objects.create_user(username=username, password=password, role=role)
        messages.success(request, "Compte créé avec succès. Connecte-toi maintenant.")
      
        return redirect('login')

    return render(request, 'register.html')


@login_required
def skillabiste_dashboard(request):
    return render(request, 'skillabiste_dashboard.html')

@login_required
def partenaire_dashboard(request):
    return render(request, 'partenaire_dashboard.html')

def is_skillabiste(user):
    return user.role == "skillabiste"

def is_partenaire(user):
    return user.role == "partenaire"


@login_required
def ajouter_projet(request):
    return render(request, 'ajouter_projet.html')

@login_required
@user_passes_test(is_skillabiste)
def skillabiste_dashboard(request):
    return render(request, 'skillabiste_dashboard.html')

@login_required
@user_passes_test(is_partenaire)
def partenaire_dashboard(request):
    return render(request, 'partenaire_dashboard.html')


@login_required
def voir_stage(request):
    return render(request, 'voir_stage.html')

def logout_view(request):
    logout(request)
    return redirect('login')


def home_view(request):
    return render(request, 'home.html')



from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Administrateur'),
        ('skillabiste', 'Skillabiste'),
        ('partenaire', 'Partenaire'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='skillabiste')

    def __str__(self):
        return f"{self.username} ({self.role})"
    

class Skillabiste(models.Model):
    user = models.OneToOneField('CustomUser', on_delete=models.CASCADE)
    telephone = models.CharField(max_length=20)
    periode_stage = models.CharField(max_length=100)
    encadrant = models.CharField(max_length=100)

    def __str__(self):
        return self.user.get_full_name()

class Stage(models.Model):
    STATUT_CHOICES = [
        ('à venir', 'À venir'),
        ('en cours', 'En cours'),
        ('terminé', 'Terminé'),
    ]
    skillabiste = models.ForeignKey(Skillabiste, on_delete=models.CASCADE)
    statut = models.CharField(max_length=20, choices=STATUT_CHOICES)
    rapport = models.FileField(upload_to='rapports/', blank=True, null=True)
    attestation = models.FileField(upload_to='attestations/', blank=True, null=True)

    def __str__(self):
        return f"{self.skillabiste.user.get_full_name()} - {self.statut}"

class Projet(models.Model):
    partenaire_nom = models.CharField(max_length=100)
    titre = models.CharField(max_length=100)
    domaine = models.CharField(max_length=100)
    objectifs = models.TextField()
    livrables = models.TextField()
    duree_estimee = models.CharField(max_length=50)
    modalites_suivi = models.TextField()

    def __str__(self):
        return self.titre

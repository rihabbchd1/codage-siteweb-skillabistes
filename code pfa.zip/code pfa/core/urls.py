
from django.urls import path
from .views import login_view, register_view, skillabiste_dashboard, partenaire_dashboard, logout_view
from .views import home_view
urlpatterns = [
    path('', home_view, name='home'),
    path('login/', login_view, name='login'),
    path('register/', register_view, name='register'),
    path('skillabiste/dashboard/', skillabiste_dashboard, name='skillabiste_dashboard'),
    path('partenaire/dashboard/', partenaire_dashboard, name='partenaire_dashboard'),
    path('logout/', logout_view, name='logout'),
]
 